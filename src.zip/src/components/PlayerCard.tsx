import React from 'react';
import type { PlayerPrediction } from '../api/cricketApi';
import { TrendingUp, Users, Trophy } from 'lucide-react';

interface PlayerCardProps {
  player: PlayerPrediction;
  rank: number;
  playerType: 'bowling' | 'batting';
  onAnalyze: () => void;
}

const PlayerCard: React.FC<PlayerCardProps> = ({ player, rank, playerType, onAnalyze }) => {
  const getRankColor = (rank: number) => {
    if (rank === 1) return 'bg-yellow-400 text-yellow-900';
    if (rank === 2) return 'bg-gray-300 text-gray-800';
    if (rank === 3) return 'bg-orange-400 text-orange-900';
    return 'bg-primary-100 text-primary-800';
  };

  const getScoreLabel = () => {
    if (playerType === 'bowling') {
      return 'Predicted Wickets';
    }
    return 'Predicted Runs';
  };

  return (
    <div className="card transition-transform hover:scale-[1.01] hover:shadow-lg min-h-[96px]">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4 flex-1">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl ${getRankColor(rank)}`}>{rank}</div>

          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-bold text-gray-900 truncate">{player.player_name}</h3>
              {rank <= 3 && (
                <span className="text-[10px] px-2 py-1 rounded-full bg-yellow-50 text-yellow-700 border border-yellow-200">Top {rank}</span>
              )}
            </div>
            <div className="flex items-center text-sm text-gray-600 mt-1 truncate">
              <Users className="w-4 h-4 mr-1" />
              <span className="truncate">{player.team}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-6">
          <div className="text-right">
            <p className="text-sm text-gray-500">{getScoreLabel()}</p>
            <div className="flex items-center space-x-1">
              <TrendingUp className="w-5 h-5 text-green-500" />
              <p className="text-2xl font-bold text-primary-600">{player.predicted_score.toFixed(2)}</p>
            </div>
          </div>

          <button
            onClick={onAnalyze}
            className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2"
            title="View detailed analysis"
          >
            <Trophy className="w-4 h-4" />
            <span>Analyze</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default PlayerCard;

