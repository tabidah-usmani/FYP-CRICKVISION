import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Brain, 
  Search, 
  Activity, 
  BarChart3,
  RefreshCw,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react';
import {
  healthCheck,
  loadData,
  trainModels,
  getLeagues,
  analyzeLeague,
  getVenues,
  getDataStats,
} from '../api/cricketApi';
import type { LeagueResponse, DataStats } from '../api/cricketApi';
import LoadingSpinner from './LoadingSpinner';
import PlayerCard from './PlayerCard';
import PlayerDetailsModal from './PlayerDetailsModal';

const Dashboard: React.FC = () => {
  const [dataLoaded, setDataLoaded] = useState(false);
  const [modelsTrained, setModelsTrained] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const [leagues, setLeagues] = useState<string[]>([]);
  const [venues, setVenues] = useState<string[]>([]);
  const [dataStats, setDataStats] = useState<DataStats | null>(null);
  
  const [selectedLeague, setSelectedLeague] = useState<string>('');
  const [selectedVenue, setSelectedVenue] = useState<string>('All Venues');
  const [topN, setTopN] = useState(10);
  
  const [analysisResults, setAnalysisResults] = useState<LeagueResponse | null>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<{ name: string; type: 'bowling' | 'batting' } | null>(null);
  const [loadingStart, setLoadingStart] = useState<number | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [analysisDiag, setAnalysisDiag] = useState<any>(null);

  // Check health on mount
  useEffect(() => {
    const initializeApp = async () => {
      try {
        await checkHealth();
        await fetchLeagues();
      } catch (err) {
        console.error('Failed to initialize app:', err);
      }
    };
    
    initializeApp();
  }, []);

  useEffect(() => {
    if (loading && loadingStart) {
      const timer = setInterval(() => {
        setElapsedSeconds(Math.floor((Date.now() - loadingStart) / 1000));
      }, 500);
      return () => clearInterval(timer);
    } else {
      setElapsedSeconds(0);
    }
  }, [loading, loadingStart]);

  const checkHealth = async () => {
    try {
      const health = await healthCheck();
      setDataLoaded(health.data_loaded);
      setModelsTrained(health.models_trained);
      
      if (health.data_loaded) {
        fetchDataStats();
        fetchVenues();
      }
    } catch (err) {
      console.error('Health check failed:', err);
      setError('Unable to connect to backend API at http://localhost:8000. Please ensure the backend server is running.');
    }
  };

  const fetchLeagues = async () => {
    try {
      const data = await getLeagues();
      setLeagues(data.leagues);
      if (data.leagues.length > 0) {
        setSelectedLeague(data.leagues[0]);
      }
    } catch (err) {
      console.error('Failed to fetch leagues:', err);
      // Don't set error here, it will be caught by health check
    }
  };

  const fetchVenues = async () => {
    try {
      const data = await getVenues();
      setVenues(['All Venues', ...data.venues]);
    } catch (err) {
      console.error('Failed to fetch venues:', err);
    }
  };

  const fetchDataStats = async () => {
    try {
      const stats = await getDataStats();
      setDataStats(stats);
    } catch (err) {
      console.error('Failed to fetch data stats:', err);
    }
  };

  const handleLoadData = async () => {
    setLoading(true);
    setLoadingStart(Date.now());
    setLoadingMessage('Loading cricket data from Supabase...');
    setError(null);
    
    try {
      await loadData();
      setDataLoaded(true);
      // After reloading data, models should be retrained
      setModelsTrained(false);
      setLoadingMessage('Data loaded successfully!');
      await fetchDataStats();
      await fetchVenues();
      setTimeout(() => { setLoading(false); setLoadingStart(null); }, 1000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to load data');
      setLoading(false);
      setLoadingStart(null);
    }
  };

  const handleTrainModels = async () => {
    setLoading(true);
    setLoadingStart(Date.now());
    setLoadingMessage('Training AI models... This may take a few minutes.');
    setError(null);
    
    try {
      await trainModels();
      setModelsTrained(true);
      setLoadingMessage('Models trained successfully!');
      setTimeout(() => { setLoading(false); setLoadingStart(null); }, 1000);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to train models');
      setLoading(false);
      setLoadingStart(null);
    }
  };

  const handleRunAnalysis = async () => {
    if (!selectedLeague) {
      setError('Please select a league');
      return;
    }

    setLoading(true);
    setLoadingStart(Date.now());
    setLoadingMessage(`Analyzing top ${topN} players in ${selectedLeague}...`);
    setError(null);
    setAnalysisDiag(null);
    
    try {
      const results = await analyzeLeague(
        selectedLeague.trim(),
        'All',
        selectedVenue === 'All Venues' ? undefined : selectedVenue.trim(),
        Number(topN)
      );
      setAnalysisResults(results);
      setLoadingMessage('Analysis complete!');
      setTimeout(() => { setLoading(false); setLoadingStart(null); }, 500);
    } catch (err: any) {
      const status = err?.response?.status;
      const detail = err?.response?.data?.detail;
      if (status === 422 && detail) {
        setError('No data found for the selected filters. Try broader filters.');
        setAnalysisDiag(detail);
      } else {
        setError(detail?.error || detail || 'Failed to run analysis');
      }
      setLoading(false);
      setLoadingStart(null);
    }
  };

  const StatusBadge = ({ active, label }: { active: boolean; label: string }) => (
    <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}`}>
      {active ? <CheckCircle className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
      <span className="font-medium">{label}</span>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="text-4xl font-bold flex items-center space-x-3">
            <Activity className="w-10 h-10" />
            <span>Cricket Talent Scout Pro</span>
          </h1>
          <p className="mt-2 text-lg text-white/90">AI-Powered Talent Identification & Performance Prediction</p>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Status Bar */}
        <div className="card mb-8 sticky top-4 z-20">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <StatusBadge active={dataLoaded} label="Data Loaded" />
              <StatusBadge active={modelsTrained} label="Models Trained" />
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={checkHealth}
                className="flex items-center space-x-2 text-gray-600 hover:text-primary-600 transition-colors"
                aria-label="Refresh Status"
              >
                <RefreshCw className="w-5 h-5" />
                <span className="hidden sm:inline">Refresh</span>
              </button>
              <button
                onClick={handleLoadData}
                className="px-3 py-2 rounded-md bg-primary-600 text-white hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={loading}
                aria-label={dataLoaded ? 'Reload Data' : 'Load Data'}
                title={dataLoaded ? 'Reload Data' : 'Load Data'}
              >
                <div className="flex items-center space-x-2">
                  <Database className="w-4 h-4" />
                  <span className="hidden sm:inline">{dataLoaded ? 'Reload Data' : 'Load Data'}</span>
                </div>
              </button>
              <button
                onClick={handleTrainModels}
                className="px-3 py-2 rounded-md bg-secondary-600 text-white hover:bg-secondary-700 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={loading || !dataLoaded}
                aria-label={modelsTrained ? 'Retrain Models' : 'Train Models'}
                title={modelsTrained ? 'Retrain Models' : 'Train Models'}
              >
                <div className="flex items-center space-x-2">
                  <Brain className="w-4 h-4" />
                  <span className="hidden sm:inline">{modelsTrained ? 'Retrain' : 'Train'}</span>
                </div>
              </button>
            </div>
          </div>

          {dataStats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 pt-4 border-t">
              <div>
                <p className="text-sm text-gray-600">Bowling Records</p>
                <p className="text-2xl font-bold text-primary-600">{dataStats.bowling_records.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Batting Records</p>
                <p className="text-2xl font-bold text-primary-600">{dataStats.batting_records.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Unique Bowlers</p>
                <p className="text-2xl font-bold text-secondary-600">{dataStats.unique_bowlers.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Unique Batsmen</p>
                <p className="text-2xl font-bold text-secondary-600">{dataStats.unique_batsmen.toLocaleString()}</p>
              </div>
            </div>
          )}
        </div>

        {/* Error Display */}
        {error && (
          <div className="card bg-red-50 border-red-200 mb-8">
            <div className="flex items-start space-x-3 text-red-700">
              <AlertCircle className="w-6 h-6 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium">{error}</p>
                {analysisDiag && (
                  <div className="mt-2 text-sm text-red-800">
                    <p>
                      League: <span className="font-semibold">{analysisDiag?.bowling_diag?.league_requested || analysisDiag?.batting_diag?.league_requested || selectedLeague}</span>
                      {selectedVenue && (
                        <> · Venue: <span className="font-semibold">{analysisDiag?.bowling_diag?.venue_requested || analysisDiag?.batting_diag?.venue_requested || selectedVenue}</span></>
                      )}
                    </p>
                    <p className="mt-1">Tip: Try “All Venues” or reduce constraints.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Loading Display */}
        {loading && (
          <div className="card mb-8">
            <LoadingSpinner message={loadingMessage} elapsedSeconds={elapsedSeconds} />
          </div>
        )}

        {/* Action Buttons moved to status bar above to save space */}

        {/* Analysis Section */}
        {dataLoaded && modelsTrained && (
          <>
            <div className="card mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <Search className="w-6 h-6 mr-2 text-primary-500" />
                Scouting Filters
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Select League</label>
                  <select
                    value={selectedLeague}
                    onChange={(e) => { setSelectedLeague(e.target.value); setSelectedVenue('All Venues'); }}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {leagues.map((league) => (
                      <option key={league} value={league}>{league}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Select Venue</label>
                  <select
                    value={selectedVenue}
                    onChange={(e) => setSelectedVenue(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {venues.map((venue) => (
                      <option key={venue} value={venue}>{venue}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-gray-700">Top Players</label>
                    <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-700 border">{topN}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <button
                      type="button"
                      onClick={() => setTopN((n) => Math.max(5, n - 1))}
                      className="px-3 py-2 rounded-md border text-gray-700 hover:bg-gray-50"
                      aria-label="Decrease top players"
                    >
                      −
                    </button>
                    <input
                      type="range"
                      min="5"
                      max="20"
                      value={topN}
                      onChange={(e) => setTopN(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <button
                      type="button"
                      onClick={() => setTopN((n) => Math.min(20, n + 1))}
                      className="px-3 py-2 rounded-md border text-gray-700 hover:bg-gray-50"
                      aria-label="Increase top players"
                    >
                      +
                    </button>
                  </div>
                  <div className="flex items-center flex-wrap gap-2 mt-2">
                    {[5, 10, 15, 20].map((n) => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setTopN(n)}
                        className={`px-3 py-1 rounded-full text-xs border ${topN === n ? 'bg-primary-600 text-white border-primary-600' : 'bg-white text-gray-700 hover:bg-gray-50'}`}
                        aria-label={`Show top ${n} players`}
                      >
                        Top {n}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <p className="text-xs text-gray-500 mt-3">Tip: Start with broader filters (All Venues), then narrow down.</p>

              <button 
                onClick={handleRunAnalysis} 
                className="btn-primary w-full mt-6"
                disabled={loading}
              >
                <BarChart3 className="w-5 h-5 inline mr-2" />
                Run Talent Analysis
              </button>
            </div>

            {/* Results with Tabs */}
            {analysisResults && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900">League: {analysisResults.league}</h2>
                </div>

                {/* Analytics Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="card">
                    <p className="text-sm text-gray-600">Total Players Analyzed</p>
                    <p className="text-3xl font-bold text-primary-600">
                      {analysisResults.top_bowlers.length + analysisResults.top_batsmen.length}
                    </p>
                  </div>
                  {analysisResults.top_bowlers.length > 0 && (
                    <div className="card">
                      <p className="text-sm text-gray-600">Top Bowler Score</p>
                      <p className="text-3xl font-bold text-green-600">
                        {analysisResults.top_bowlers[0].predicted_score.toFixed(2)}
                      </p>
                    </div>
                  )}
                  {analysisResults.top_batsmen.length > 0 && (
                    <div className="card">
                      <p className="text-sm text-gray-600">Top Batsman Score</p>
                      <p className="text-3xl font-bold text-blue-600">
                        {analysisResults.top_batsmen[0].predicted_score.toFixed(2)}
                      </p>
                    </div>
                  )}
                </div>

                <div className="card">
                  <div className="flex items-center space-x-2 border-b pb-3 mb-4">
                    <button
                      onClick={() => setSelectedPlayer(null)}
                      className="px-4 py-2 rounded-md bg-primary-50 text-primary-700 border border-primary-200"
                      disabled
                    >
                      Results
                    </button>
                    <div className="flex items-center space-x-2 ml-auto text-sm text-gray-500">
                      <span className="px-2 py-1 bg-gray-100 rounded-full">Bowlers: {analysisResults.top_bowlers.length}</span>
                      <span className="px-2 py-1 bg-gray-100 rounded-full">Batsmen: {analysisResults.top_batsmen.length}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-3">🎯 Top Bowlers</h3>
                      <div className="space-y-4">
                        {analysisResults.top_bowlers.map((bowler, idx) => (
                          <PlayerCard
                            key={`bowler-${idx}`}
                            player={bowler}
                            rank={idx + 1}
                            playerType="bowling"
                            onAnalyze={() => setSelectedPlayer({ name: bowler.player_name, type: 'bowling' })}
                          />
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-3">🏏 Top Batsmen</h3>
                      <div className="space-y-4">
                        {analysisResults.top_batsmen.map((batsman, idx) => (
                          <PlayerCard
                            key={`batsman-${idx}`}
                            player={batsman}
                            rank={idx + 1}
                            playerType="batting"
                            onAnalyze={() => setSelectedPlayer({ name: batsman.player_name, type: 'batting' })}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* Welcome Message */}
        {!analysisResults && dataLoaded && modelsTrained && !loading && (
          <div className="card text-center py-12">
            <Activity className="w-20 h-20 mx-auto text-primary-500 mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready for Analysis!</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Configure your scouting filters above and click "Run Talent Analysis" to discover top performers 
              across cricket leagues with AI-powered predictions.
            </p>
          </div>
        )}
      </div>

      {/* Player Details Modal */}
      {selectedPlayer && (
        <PlayerDetailsModal
          playerName={selectedPlayer.name}
          playerType={selectedPlayer.type}
          onClose={() => setSelectedPlayer(null)}
        />
      )}
    </div>
  );
};

export default Dashboard;

