import React, { useEffect, useState } from 'react';
import { X, TrendingUp, TrendingDown, Award, Target } from 'lucide-react';
import { analyzePlayer } from '../api/cricketApi';
import type { PlayerAnalysisResponse } from '../api/cricketApi';
import LoadingSpinner from './LoadingSpinner';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  Legend,
} from 'recharts';

interface PlayerDetailsModalProps {
  playerName: string;
  playerType: 'bowling' | 'batting';
  onClose: () => void;
}

const PlayerDetailsModal: React.FC<PlayerDetailsModalProps> = ({ playerName, playerType, onClose }) => {
  const [playerData, setPlayerData] = useState<PlayerAnalysisResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPlayerData = async () => {
      try {
        setLoading(true);
        const data = await analyzePlayer(playerName, playerType);
        setPlayerData(data);
      } catch (err: any) {
        setError(err.response?.data?.detail || 'Failed to load player data');
      } finally {
        setLoading(false);
      }
    };

    fetchPlayerData();
  }, [playerName, playerType]);

  const getRating = (value: number, type: string) => {
    if (type === 'wickets') {
      if (value > 2.5) return { label: 'Excellent', color: 'text-green-600', icon: TrendingUp };
      if (value > 1.5) return { label: 'Good', color: 'text-blue-600', icon: TrendingUp };
      return { label: 'Developing', color: 'text-orange-600', icon: TrendingDown };
    } else if (type === 'runs') {
      if (value > 40) return { label: 'Excellent', color: 'text-green-600', icon: TrendingUp };
      if (value > 25) return { label: 'Good', color: 'text-blue-600', icon: TrendingUp };
      return { label: 'Developing', color: 'text-orange-600', icon: TrendingDown };
    }
    return { label: 'Average', color: 'text-gray-600', icon: Target };
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 py-8">
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={onClose}></div>

        <div className="inline-block w-full max-w-4xl my-8 text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl h-[80vh] flex flex-col overflow-hidden">
          <div className="bg-gradient-to-r from-primary-500 to-secondary-500 px-6 py-6 flex-shrink-0 rounded-t-2xl">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-bold text-white flex items-center space-x-3">
                <Award className="w-8 h-8" />
                <span>{playerName}</span>
              </h2>
              <button
                onClick={onClose}
                className="text-white hover:text-gray-200 transition-colors"
              >
                <X className="w-8 h-8" />
              </button>
            </div>
            <p className="text-white/90 mt-2 text-lg capitalize">{playerType} Analysis</p>
          </div>

          <div className="px-6 py-6 overflow-y-auto flex-1">
            {loading && <LoadingSpinner message="Loading player analysis..." />}

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
                {error}
              </div>
            )}

            {playerData && !loading && (
              <div className="space-y-6">
                {/* Trend Charts */}
                {playerData.recent_matches && playerData.recent_matches.length > 0 && (
                  <div className="card">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">📈 Performance Trends (Last 10 Matches)</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Line chart: wickets or runs */}
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={playerData.recent_matches.slice(0, 10).map((m: any, i: number) => ({
                              idx: (m.match_id ?? i).toString(),
                              primary: playerType === 'bowling' ? Number(m['Wickets Taken'] || 0) : Number(m['Total Runs'] || 0),
                            }))}
                            margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="idx" tick={{ fontSize: 12 }} />
                            <YAxis tick={{ fontSize: 12 }} />
                            <Tooltip />
                            <Legend />
                            <Line
                              type="monotone"
                              dataKey="primary"
                              name={playerType === 'bowling' ? 'Wickets' : 'Runs'}
                              stroke={playerType === 'bowling' ? '#22c55e' : '#3b82f6'}
                              strokeWidth={2}
                              dot={{ r: 2 }}
                              activeDot={{ r: 4 }}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>

                      {/* Bar chart: economy/strike rate */}
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={playerData.recent_matches.slice(0, 10).map((m: any, i: number) => ({
                              idx: (m.match_id ?? i).toString(),
                              metric:
                                playerType === 'bowling'
                                  ? Number((m['Economy Rate'] ?? 0).toFixed ? m['Economy Rate'] : m['Economy Rate'] || 0)
                                  : Number((m['Strike Rate'] ?? 0).toFixed ? m['Strike Rate'] : m['Strike Rate'] || 0),
                            }))}
                            margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="idx" tick={{ fontSize: 12 }} />
                            <YAxis tick={{ fontSize: 12 }} />
                            <Tooltip />
                            <Legend />
                            <Bar
                              dataKey="metric"
                              name={playerType === 'bowling' ? 'Economy' : 'Strike Rate'}
                              fill={playerType === 'bowling' ? '#10b981' : '#8b5cf6'}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                )}
                {/* Key Performance Indicators */}
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">📊 Key Performance Indicators</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {playerType === 'bowling' ? (
                      <>
                        <div className="card bg-blue-50 border-blue-200">
                          <p className="text-sm text-gray-600">Average Wickets</p>
                          <p className="text-3xl font-bold text-blue-600">{playerData.stats.avg_wickets?.toFixed(2) || 'N/A'}</p>
                        </div>
                        <div className="card bg-green-50 border-green-200">
                          <p className="text-sm text-gray-600">Average Economy</p>
                          <p className="text-3xl font-bold text-green-600">{playerData.stats.avg_economy?.toFixed(2) || 'N/A'}</p>
                        </div>
                        <div className="card bg-purple-50 border-purple-200">
                          <p className="text-sm text-gray-600">Dot Ball %</p>
                          <p className="text-3xl font-bold text-purple-600">{playerData.stats.avg_dot_pct?.toFixed(1) || 'N/A'}%</p>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="card bg-blue-50 border-blue-200">
                          <p className="text-sm text-gray-600">Average Runs</p>
                          <p className="text-3xl font-bold text-blue-600">{playerData.stats.avg_runs?.toFixed(2) || 'N/A'}</p>
                        </div>
                        <div className="card bg-green-50 border-green-200">
                          <p className="text-sm text-gray-600">Strike Rate</p>
                          <p className="text-3xl font-bold text-green-600">{playerData.stats.avg_strike_rate?.toFixed(2) || 'N/A'}</p>
                        </div>
                        <div className="card bg-purple-50 border-purple-200">
                          <p className="text-sm text-gray-600">Boundary %</p>
                          <p className="text-3xl font-bold text-purple-600">{playerData.stats.avg_boundary_pct?.toFixed(1) || 'N/A'}%</p>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* Performance Rating */}
                <div className="card bg-gradient-to-r from-primary-50 to-secondary-50">
                  <h3 className="text-lg font-bold text-gray-900 mb-2">⭐ Performance Rating</h3>
                  {playerType === 'bowling' && playerData.stats.avg_wickets !== undefined && (
                    <div className="flex items-center space-x-3">
                      {(() => {
                        const rating = getRating(playerData.stats.avg_wickets, 'wickets');
                        const Icon = rating.icon;
                        return (
                          <>
                            <Icon className={`w-6 h-6 ${rating.color}`} />
                            <span className={`text-xl font-bold ${rating.color}`}>{rating.label}</span>
                          </>
                        );
                      })()}
                    </div>
                  )}
                  {playerType === 'batting' && playerData.stats.avg_runs !== undefined && (
                    <div className="flex items-center space-x-3">
                      {(() => {
                        const rating = getRating(playerData.stats.avg_runs, 'runs');
                        const Icon = rating.icon;
                        return (
                          <>
                            <Icon className={`w-6 h-6 ${rating.color}`} />
                            <span className={`text-xl font-bold ${rating.color}`}>{rating.label}</span>
                          </>
                        );
                      })()}
                    </div>
                  )}
                </div>

                {/* Recent Matches */}
                {playerData.recent_matches && playerData.recent_matches.length > 0 && (
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">📈 Recent Match Performance</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="bg-gray-100 border-b-2 border-gray-300">
                          <tr>
                            <th className="px-4 py-3 font-semibold">Match</th>
                            <th className="px-4 py-3 font-semibold">Venue</th>
                            {playerType === 'bowling' ? (
                              <>
                                <th className="px-4 py-3 font-semibold">Wickets</th>
                                <th className="px-4 py-3 font-semibold">Economy</th>
                                <th className="px-4 py-3 font-semibold">Dot Ball %</th>
                              </>
                            ) : (
                              <>
                                <th className="px-4 py-3 font-semibold">Runs</th>
                                <th className="px-4 py-3 font-semibold">Strike Rate</th>
                                <th className="px-4 py-3 font-semibold">Boundary %</th>
                              </>
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {playerData.recent_matches.slice(0, 10).map((match, idx) => (
                            <tr key={idx} className="border-b hover:bg-gray-50">
                              <td className="px-4 py-3">{match.match_id || 'N/A'}</td>
                              <td className="px-4 py-3">{match.venue || 'N/A'}</td>
                              {playerType === 'bowling' ? (
                                <>
                                  <td className="px-4 py-3 font-semibold">{match['Wickets Taken'] || 0}</td>
                                  <td className="px-4 py-3">{match['Economy Rate']?.toFixed(2) || 'N/A'}</td>
                                  <td className="px-4 py-3">{match['Dot Ball %']?.toFixed(1) || 'N/A'}%</td>
                                </>
                              ) : (
                                <>
                                  <td className="px-4 py-3 font-semibold">{match['Total Runs'] || 0}</td>
                                  <td className="px-4 py-3">{match['Strike Rate']?.toFixed(2) || 'N/A'}</td>
                                  <td className="px-4 py-3">{match['Boundary %']?.toFixed(1) || 'N/A'}%</td>
                                </>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* AI Insights */}
                <div className="card bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">💡 AI-Powered Insights</h3>
                  <div className="space-y-2 text-gray-700">
                    {playerType === 'bowling' ? (
                      <>
                        {playerData.stats.avg_wickets && playerData.stats.avg_wickets > 2 && (
                          <p>✓ <strong>High Impact:</strong> Consistent wicket-taker who can change games</p>
                        )}
                        {playerData.stats.avg_economy && playerData.stats.avg_economy < 7 && (
                          <p>✓ <strong>Economical:</strong> Great at building pressure and controlling runs</p>
                        )}
                        {playerData.stats.avg_dot_pct && playerData.stats.avg_dot_pct > 50 && (
                          <p>✓ <strong>Pressure Builder:</strong> Excellent at creating dot-ball pressure</p>
                        )}
                      </>
                    ) : (
                      <>
                        {playerData.stats.avg_runs && playerData.stats.avg_runs > 35 && (
                          <p>✓ <strong>Match Winner:</strong> Consistent high scorer who builds innings</p>
                        )}
                        {playerData.stats.avg_strike_rate && playerData.stats.avg_strike_rate > 140 && (
                          <p>✓ <strong>Power Hitter:</strong> Aggressive striker who accelerates innings</p>
                        )}
                        {playerData.stats.avg_boundary_pct && playerData.stats.avg_boundary_pct > 20 && (
                          <p>✓ <strong>Boundary Hunter:</strong> Finds boundaries regularly</p>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerDetailsModal;

