import React from 'react';

interface LoadingSpinnerProps {
  message?: string;
  elapsedSeconds?: number;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ message, elapsedSeconds }) => {
  const formatElapsed = (secs?: number) => {
    if (secs === undefined) return '';
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = Math.floor(secs % 60).toString().padStart(2, '0');
    return ` (${m}:${s})`;
  };
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="relative w-16 h-16">
        <div className="absolute top-0 left-0 w-full h-full border-4 border-primary-200 rounded-full"></div>
        <div className="absolute top-0 left-0 w-full h-full border-4 border-primary-500 rounded-full border-t-transparent animate-spin"></div>
      </div>
      {message && (
        <p className="mt-4 text-gray-600 font-medium">{message}{formatElapsed(elapsedSeconds)}</p>
      )}
    </div>
  );
};

export default LoadingSpinner;

