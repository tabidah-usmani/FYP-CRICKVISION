import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Types
export interface PlayerPrediction {
  player_name: string;
  team: string;
  predicted_score: number;
  match_type?: string;
}

export interface LeagueResponse {
  league: string;
  top_bowlers: PlayerPrediction[];
  top_batsmen: PlayerPrediction[];
}

export interface HealthResponse {
  status: string;
  data_loaded: boolean;
  models_trained: boolean;
}

export interface DataStats {
  bowling_records: number;
  batting_records: number;
  unique_bowlers: number;
  unique_batsmen: number;
}

export interface PlayerAnalysisResponse {
  player_name: string;
  player_type: string;
  stats: {
    avg_wickets?: number;
    avg_economy?: number;
    avg_dot_pct?: number;
    avg_runs?: number;
    avg_strike_rate?: number;
    avg_boundary_pct?: number;
  };
  recent_matches: any[];
}

// API Functions
export const healthCheck = async (): Promise<HealthResponse> => {
  const response = await api.get<HealthResponse>('/health');
  return response.data;
};

export const loadData = async () => {
  const response = await api.post('/data/load');
  return response.data;
};

export const getDataStats = async (): Promise<DataStats> => {
  const response = await api.get<DataStats>('/data/stats');
  return response.data;
};

export const trainModels = async (horizon: number = 5, formWindow: number = 3) => {
  const response = await api.post('/models/train', {
    horizon,
    form_window: formWindow,
  });
  return response.data;
};

export const getLeagues = async () => {
  const response = await api.get('/leagues');
  return response.data;
};

export const getLeagueTeams = async (league: string) => {
  const response = await api.get(`/leagues/${league}/teams`);
  return response.data;
};

export const analyzeLeague = async (
  league: string,
  formatType: string = 'All',
  venue?: string,
  topN: number = 10
): Promise<LeagueResponse> => {
  const response = await api.post<LeagueResponse>('/analysis/league', {
    league,
    format_type: formatType,
    venue,
    top_n: topN,
  });
  return response.data;
};

export const analyzePlayer = async (
  playerName: string,
  playerType: 'bowling' | 'batting',
  numMatches: number = 10
): Promise<PlayerAnalysisResponse> => {
  const response = await api.post<PlayerAnalysisResponse>('/analysis/player', {
    player_name: playerName,
    player_type: playerType,
    num_matches: numMatches,
  });
  return response.data;
};

export const getVenues = async () => {
  const response = await api.get('/venues');
  return response.data;
};

export default api;

